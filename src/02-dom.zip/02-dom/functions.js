const functions = {
    myItems: (yahoo, google) =>{
        google.innerHTML = '';
        for (let b of yahoo){
        let addItem = document.createElement("li");
        addItem.className="linux";
        addItem.textContent=b ;
        google.appendChild(addItem);
        }
    },
    
    plusItems: (sina,index) =>{
        sina.push("Item "+index);
        return sina;
    },
    startItems: (sina,index) =>{
        sina.unshift("Item "+index);
        return sina;
    },
    deleteItems: (sina) =>{
        sina.pop();
        return sina;
    },

    addCards: (node, counter) =>{
        let newDiv = document.createElement('div');
        newDiv.className="card";
        newDiv.setAttribute('counter',counter);
        newDiv.textContent = `card # ${counter}`;
        node.appendChild(newDiv);
        
        let brk = document.createElement('br');
        newDiv.appendChild(brk);
        
        let addBefore = document.createElement('button');
        addBefore.className="ac";
        addBefore.setAttribute('id', "first") ;
        addBefore.textContent="addBefore";
        newDiv.appendChild(addBefore);

        let addAfter = document.createElement('button');
        addAfter.className="ac";
        addAfter.setAttribute('id', "second") ;
        addAfter.textContent="addAfter";
        newDiv.appendChild(addAfter);

        let brk1 = document.createElement('br');
        newDiv.appendChild(brk1);

        let deleteAdd = document.createElement('button');
        deleteAdd.className="ac";
        deleteAdd.setAttribute('id', "third") ;
        deleteAdd.textContent="Delete";
        newDiv.appendChild(deleteAdd);
        
    }

    // myCards: (array, node) =>{
    //     node.innerHTML = '';
    //     for (let b of arry){
    //         addCards(node, counter);
    //     }
    // }
}
export default functions;