import functions from './functions.js'

test('show item', () => {
    let addItem = document.createElement("li");
    functions.myItems(addItem);

});